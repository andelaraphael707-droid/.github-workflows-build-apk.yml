package com.raphael.klyve;

import android.Manifest;
import android.annotation.SuppressLint;
import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.content.pm.ServiceInfo;
import android.media.AudioFormat;
import android.media.AudioRecord;
import android.media.MediaRecorder;
import android.os.Build;
import android.os.Handler;
import android.os.IBinder;
import android.os.Looper;
import android.os.PowerManager;
import android.os.Process;
import android.os.VibrationEffect;
import android.os.Vibrator;
import android.os.VibratorManager;
import android.widget.Toast;

import androidx.annotation.Nullable;
import androidx.core.app.NotificationCompat;
import androidx.core.app.ServiceCompat;
import androidx.core.content.ContextCompat;

/**
 * Service au premier plan (type « microphone ») qui écoute les 2 claps.
 *
 * - Notification persistante « Détection des claps active » avec bouton « Arrêter ».
 * - Le micro sert UNIQUEMENT à alimenter ClapDetector (analyse locale) : aucun son n'est
 *   enregistré, stocké ni envoyé (les tampons audio sont réutilisés et écrasés en continu).
 * - Double clap → 1re fois : torche ON + écran réveillé (5 s) ; 2e fois : torche OFF + WakeLock libéré.
 * - START_NOT_STICKY : Android 12+/14+ interdit de relancer un service micro depuis l'arrière-plan ;
 *   MainActivity relance la détection quand l'appli repasse au premier plan.
 */
public class ClapDetectionService extends Service implements ClapDetector.Listener {

    public static final String ACTION_START = "com.raphael.klyve.action.START_CLAP_SERVICE";
    public static final String ACTION_STOP = "com.raphael.klyve.action.STOP_CLAP_SERVICE";

    private static final String CHANNEL_ID = "klyve_clap_detection";
    private static final int NOTIFICATION_ID = 4201;
    private static final long CPU_LOCK_TIMEOUT_MS = 4L * 60L * 60L * 1000L;
    private static final int FRAMES_PER_CHECK = 100;       // ~2 s
    private static final int FRAMES_PER_CPU_REFRESH = 90000; // ~30 min

    private static volatile boolean running = false;
    private static volatile ClapDetectionService instance = null;

    private final Handler mainHandler = new Handler(Looper.getMainLooper());
    private ClapPrefs prefs;
    private ClapDetector detector;
    private TorchController torch;
    private ScreenWaker waker;
    private volatile PowerManager.WakeLock cpuLock;
    private volatile boolean stopRequested = false;
    private Thread worker;
    private boolean noFlashWarned = false;

    // ------------------------------------------------------------ API statique

    public static boolean isRunning() {
        return running;
    }

    public static boolean hasMicPermission(Context context) {
        return ContextCompat.checkSelfPermission(context, Manifest.permission.RECORD_AUDIO)
                == PackageManager.PERMISSION_GRANTED;
    }

    /**
     * Démarre le service. À appeler quand l'appli est visible (exigence d'Android pour le micro au
     * premier plan). Retourne false si Android refuse ou si la permission micro manque.
     */
    public static boolean start(Context context) {
        if (!hasMicPermission(context)) {
            return false;
        }
        try {
            Intent i = new Intent(context, ClapDetectionService.class).setAction(ACTION_START);
            ContextCompat.startForegroundService(context, i);
            return true;
        } catch (RuntimeException e) { // ex. ForegroundServiceStartNotAllowedException (Android 12+)
            return false;
        }
    }

    public static void stop(Context context) {
        try {
            context.stopService(new Intent(context, ClapDetectionService.class));
        } catch (RuntimeException ignored) {
        }
    }

    /** Applique immédiatement les réglages modifiés si le service tourne. */
    public static void notifySettingsChanged() {
        final ClapDetectionService s = instance;
        if (s != null) {
            s.mainHandler.post(s::applyConfig);
        }
    }

    // ------------------------------------------------------------ cycle de vie

    @Override
    public void onCreate() {
        super.onCreate();
        instance = this;
        prefs = new ClapPrefs(this);
        detector = new ClapDetector(this);
        torch = new TorchController(this);
        waker = new ScreenWaker(this);
        createChannel();
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        final String action = intent == null ? null : intent.getAction();

        if (ACTION_STOP.equals(action)) {
            // Bouton « Arrêter » : l'utilisateur désactive la fonction
            prefs.setEnabled(false);
            stopSelf();
            return START_NOT_STICKY;
        }

        // Chaque startForegroundService() doit être suivi d'un startForeground() (délai de 5 s).
        if (!enterForeground()) {
            ClapEvents.emit("error", false, false, getString(R.string.toast_start_failed));
            toast(R.string.toast_start_failed);
            stopSelf();
            return START_NOT_STICKY;
        }

        if (!hasMicPermission(this)) {
            ClapEvents.emit("error", false, false, getString(R.string.toast_no_mic));
            stopSelf();
            return START_NOT_STICKY;
        }

        if (worker != null && worker.isAlive()) {
            return START_NOT_STICKY; // déjà en écoute : pas de doublon de thread/service
        }

        detector.reset();
        applyConfig();
        torch.start();
        stopRequested = false;
        running = true;
        worker = new Thread(this::captureLoop, "klyve-clap-capture");
        worker.start();
        ClapEvents.emit("status", true, torch.isOn(), null);
        return START_NOT_STICKY;
    }

    @Override
    public void onDestroy() {
        stopRequested = true;
        final Thread w = worker;
        worker = null;
        if (w != null) {
            try {
                w.join(800);
            } catch (InterruptedException e) {
                Thread.currentThread().interrupt();
            }
        }
        mainHandler.removeCallbacksAndMessages(null);
        torch.release();   // torche éteinte : aucune torche « coincée »
        waker.release();   // aucun WakeLock oublié
        releaseCpuLock();
        running = false;
        instance = null;
        ClapEvents.emit("status", false, false, null);
        super.onDestroy();
    }

    @Nullable
    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }

    // ------------------------------------------------------------ configuration

    private void applyConfig() {
        detector.configure(prefs.getSensitivity(), prefs.getMaxGapMs());
        if (prefs.isKeepCpu()) {
            acquireCpuLock();
        } else {
            releaseCpuLock();
        }
    }

    private void acquireCpuLock() {
        try {
            PowerManager pm = (PowerManager) getSystemService(Context.POWER_SERVICE);
            if (pm == null) {
                return;
            }
            PowerManager.WakeLock l = cpuLock;
            if (l == null) {
                l = pm.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "KlyveAI:ClapListen");
                l.setReferenceCounted(false);
                cpuLock = l;
            }
            l.acquire(CPU_LOCK_TIMEOUT_MS); // avec délai : jamais de WakeLock éternel
        } catch (RuntimeException ignored) {
        }
    }

    private void releaseCpuLock() {
        final PowerManager.WakeLock l = cpuLock;
        cpuLock = null;
        try {
            if (l != null && l.isHeld()) {
                l.release();
            }
        } catch (RuntimeException ignored) {
        }
    }

    // ------------------------------------------------------------ capture audio

    private void captureLoop() {
        Process.setThreadPriority(Process.THREAD_PRIORITY_AUDIO);
        final short[] buf = new short[ClapDetector.FRAME_SIZE]; // réutilisé : pas d'allocation dans la boucle
        String failure = null;
        int restarts = 0;
        AudioRecord rec = null;

        try {
            outer:
            while (!stopRequested) {
                rec = openRecorder();
                if (rec == null) {
                    failure = getString(R.string.toast_mic_failed);
                    break;
                }
                try {
                    rec.startRecording();
                } catch (IllegalStateException e) {
                    failure = getString(R.string.toast_mic_failed);
                    break;
                }
                if (rec.getRecordingState() != AudioRecord.RECORDSTATE_RECORDING) {
                    failure = getString(R.string.toast_mic_failed);
                    break;
                }

                int frames = 0;
                boolean broken = false;
                while (!stopRequested) {
                    final int n = rec.read(buf, 0, buf.length);
                    if (n > 0) {
                        detector.process(buf, n);
                    } else if (n < 0) {
                        broken = true; // micro perdu (autre appli, appel...) → on retente
                        break;
                    } else {
                        Thread.sleep(5);
                    }
                    frames++;
                    if (frames % FRAMES_PER_CHECK == 0 && !hasMicPermission(this)) {
                        failure = getString(R.string.toast_mic_revoked);
                        break outer;
                    }
                    if (frames % FRAMES_PER_CPU_REFRESH == 0 && prefs.isKeepCpu()) {
                        acquireCpuLock();
                    }
                }
                releaseRecorder(rec);
                rec = null;
                if (stopRequested) {
                    break;
                }
                if (broken) {
                    restarts++;
                    if (restarts > 3) {
                        failure = getString(R.string.toast_mic_failed);
                        break;
                    }
                    Thread.sleep(500);
                    detector.reset();
                    applyConfigOnWorker();
                }
            }
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
        } catch (RuntimeException e) {
            failure = getString(R.string.toast_mic_failed);
        } finally {
            releaseRecorder(rec); // micro TOUJOURS libéré
        }

        if (failure != null && !stopRequested) {
            final String msg = failure;
            mainHandler.post(() -> {
                if (stopRequested) {
                    return;
                }
                ClapEvents.emit("error", false, false, msg);
                Toast.makeText(getApplicationContext(), msg, Toast.LENGTH_LONG).show();
                stopSelf();
            });
        }
    }

    private void applyConfigOnWorker() {
        detector.configure(prefs.getSensitivity(), prefs.getMaxGapMs());
    }

    @SuppressLint("MissingPermission")
    private AudioRecord openRecorder() {
        final int minBuf = AudioRecord.getMinBufferSize(
                ClapDetector.SAMPLE_RATE, AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT);
        if (minBuf <= 0) {
            return null;
        }
        final int bufBytes = Math.max(minBuf, ClapDetector.FRAME_SIZE * 2 * 8);
        // VOICE_RECOGNITION : pas de compression/AGC, les transitoires (claps) sont mieux préservés.
        final int[] sources = {MediaRecorder.AudioSource.VOICE_RECOGNITION, MediaRecorder.AudioSource.MIC};
        for (int source : sources) {
            AudioRecord r = null;
            try {
                r = new AudioRecord(source, ClapDetector.SAMPLE_RATE,
                        AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT, bufBytes);
                if (r.getState() == AudioRecord.STATE_INITIALIZED) {
                    return r;
                }
            } catch (RuntimeException e) {
                // on essaie la source suivante
            }
            releaseRecorder(r);
        }
        return null;
    }

    private static void releaseRecorder(AudioRecord r) {
        if (r == null) {
            return;
        }
        try {
            if (r.getRecordingState() == AudioRecord.RECORDSTATE_RECORDING) {
                r.stop();
            }
        } catch (RuntimeException ignored) {
        }
        try {
            r.release();
        } catch (RuntimeException ignored) {
        }
    }

    // ------------------------------------------------------------ action sur double clap

    /** Appelé depuis le thread de capture : on bascule sur le thread principal. */
    @Override
    public void onDoubleClap() {
        mainHandler.post(this::handleDoubleClap);
    }

    private void handleDoubleClap() {
        if (stopRequested) {
            return;
        }
        final long wakeMs = prefs.getWakeSeconds() * 1000L;
        ClapEvents.emit("doubleClap", true, torch.isOn(), null);

        if (!torch.isSupported()) {
            // Pas de flash : erreur propre (une seule fois), on réveille quand même l'écran.
            if (!noFlashWarned) {
                noFlashWarned = true;
                toast(R.string.toast_no_flash);
                ClapEvents.emit("error", true, false, getString(R.string.toast_no_flash));
            }
            waker.wakeFor(wakeMs);
            vibrateShort();
            return;
        }

        if (!torch.isOn()) {
            // PREMIER ÉTAT : torche ON + écran réveillé ~5 s (WakeLock temporaire, libération automatique)
            final boolean ok = torch.set(true);
            waker.wakeFor(wakeMs);
            vibrateShort();
            if (!ok) {
                toast(R.string.toast_torch_busy);
                ClapEvents.emit("error", true, false, getString(R.string.toast_torch_busy));
            }
        } else {
            // DEUXIÈME DÉTECTION : torche OFF + WakeLock libéré
            torch.set(false);
            waker.release();
            vibrateShort();
        }
        ClapEvents.emit("status", true, torch.isOn(), null);
    }

    @SuppressWarnings("deprecation")
    private void vibrateShort() {
        if (!prefs.isVibrate()) {
            return;
        }
        try {
            Vibrator v;
            if (Build.VERSION.SDK_INT >= 31) {
                VibratorManager vm = (VibratorManager) getSystemService(Context.VIBRATOR_MANAGER_SERVICE);
                v = vm == null ? null : vm.getDefaultVibrator();
            } else {
                v = (Vibrator) getSystemService(Context.VIBRATOR_SERVICE);
            }
            if (v == null || !v.hasVibrator()) {
                return;
            }
            if (Build.VERSION.SDK_INT >= 26) {
                v.vibrate(VibrationEffect.createOneShot(60, VibrationEffect.DEFAULT_AMPLITUDE));
            } else {
                v.vibrate(60);
            }
        } catch (RuntimeException ignored) {
        }
    }

    private void toast(int resId) {
        try {
            Toast.makeText(getApplicationContext(), resId, Toast.LENGTH_LONG).show();
        } catch (RuntimeException ignored) {
        }
    }

    // ------------------------------------------------------------ notification

    private boolean enterForeground() {
        try {
            final int type = Build.VERSION.SDK_INT >= 30 ? ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE : 0;
            ServiceCompat.startForeground(this, NOTIFICATION_ID, buildNotification(), type);
            return true;
        } catch (RuntimeException e) { // SecurityException, ForegroundServiceStartNotAllowedException...
            return false;
        }
    }

    private void createChannel() {
        if (Build.VERSION.SDK_INT >= 26) {
            NotificationManager nm = getSystemService(NotificationManager.class);
            if (nm != null) {
                NotificationChannel ch = new NotificationChannel(
                        CHANNEL_ID, getString(R.string.clap_channel_name), NotificationManager.IMPORTANCE_LOW);
                ch.setDescription(getString(R.string.clap_channel_desc));
                ch.setShowBadge(false);
                nm.createNotificationChannel(ch);
            }
        }
    }

    private Notification buildNotification() {
        final Intent open = new Intent(this, MainActivity.class)
                .addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP | Intent.FLAG_ACTIVITY_CLEAR_TOP);
        final PendingIntent openPi = PendingIntent.getActivity(
                this, 0, open, PendingIntent.FLAG_IMMUTABLE | PendingIntent.FLAG_UPDATE_CURRENT);

        final Intent stop = new Intent(this, ClapDetectionService.class).setAction(ACTION_STOP);
        final PendingIntent stopPi = PendingIntent.getService(
                this, 1, stop, PendingIntent.FLAG_IMMUTABLE | PendingIntent.FLAG_UPDATE_CURRENT);

        return new NotificationCompat.Builder(this, CHANNEL_ID)
                .setSmallIcon(R.drawable.ic_stat_klyve)
                .setContentTitle(getString(R.string.clap_notif_title))
                .setContentText(getString(R.string.clap_notif_text))
                .setContentIntent(openPi)
                .addAction(R.drawable.ic_stat_klyve, getString(R.string.clap_notif_stop), stopPi)
                .setOngoing(true)
                .setOnlyAlertOnce(true)
                .setShowWhen(false)
                .setCategory(NotificationCompat.CATEGORY_SERVICE)
                .setPriority(NotificationCompat.PRIORITY_LOW)
                .setForegroundServiceBehavior(NotificationCompat.FOREGROUND_SERVICE_IMMEDIATE)
                .build();
    }
}
