package com.raphael.klyve;

import android.Manifest;
import android.os.Build;

import androidx.core.content.ContextCompat;

import com.getcapacitor.JSObject;
import com.getcapacitor.Plugin;
import com.getcapacitor.PluginCall;
import com.getcapacitor.PluginMethod;
import com.getcapacitor.annotation.CapacitorPlugin;

/**
 * Plugin Capacitor « KlyveClap » : pont optionnel entre l'interface web et la détection native.
 * index.html n'est pas modifié et n'en a pas besoin ; ce pont prépare une future intégration
 * (boutons ON/OFF, sensibilité, etc.) via :
 *
 *   const { KlyveClap } = Capacitor.Plugins;
 *   await KlyveClap.start();
 *   await KlyveClap.setSettings({ sensitivity: 2, wakeSeconds: 5, vibrate: true, background: true });
 *   KlyveClap.addListener('clapEvent', e => console.log(e)); // {type, running, torchOn, message?}
 */
@CapacitorPlugin(name = "KlyveClap")
public class KlyveClapPlugin extends Plugin {

    @Override
    public void load() {
        ClapEvents.setListener((type, running, torchOn, message) -> {
            JSObject data = new JSObject();
            data.put("type", type);
            data.put("running", running);
            data.put("torchOn", torchOn);
            if (message != null) {
                data.put("message", message);
            }
            notifyListeners("clapEvent", data);
        });
    }

    @Override
    protected void handleOnDestroy() {
        ClapEvents.setListener(null); // pas de listener orphelin
    }

    @PluginMethod
    public void getStatus(PluginCall call) {
        call.resolve(buildStatus());
    }

    /** Active la détection (demande les autorisations si besoin). Le résultat arrive via l'événement clapEvent. */
    @PluginMethod
    public void start(final PluginCall call) {
        final MainActivity activity = mainActivity();
        if (activity == null) {
            call.reject("Activité indisponible");
            return;
        }
        activity.runOnUiThread(() -> {
            activity.enableClaps();
            call.resolve(buildStatus());
        });
    }

    @PluginMethod
    public void stop(final PluginCall call) {
        final MainActivity activity = mainActivity();
        if (activity == null) {
            call.reject("Activité indisponible");
            return;
        }
        activity.runOnUiThread(() -> {
            activity.disableClaps(false);
            call.resolve(buildStatus());
        });
    }

    @PluginMethod
    public void getSettings(PluginCall call) {
        call.resolve(buildSettings());
    }

    @PluginMethod
    public void setSettings(PluginCall call) {
        final ClapPrefs prefs = new ClapPrefs(getContext());
        final Integer sensitivity = call.getInt("sensitivity");
        final Integer wakeSeconds = call.getInt("wakeSeconds");
        final Integer maxGapMs = call.getInt("maxGapMs");
        final Boolean vibrate = call.getBoolean("vibrate");
        final Boolean background = call.getBoolean("background");
        final Boolean keepCpu = call.getBoolean("keepCpu");
        if (sensitivity != null) prefs.setSensitivity(sensitivity);
        if (wakeSeconds != null) prefs.setWakeSeconds(wakeSeconds);
        if (maxGapMs != null) prefs.setMaxGapMs(maxGapMs);
        if (vibrate != null) prefs.setVibrate(vibrate);
        if (background != null) prefs.setBackground(background);
        if (keepCpu != null) prefs.setKeepCpu(keepCpu);
        ClapDetectionService.notifySettingsChanged();
        call.resolve(buildSettings());
    }

    // ------------------------------------------------------------ utilitaires

    private MainActivity mainActivity() {
        return getActivity() instanceof MainActivity ? (MainActivity) getActivity() : null;
    }

    private JSObject buildSettings() {
        final ClapPrefs prefs = new ClapPrefs(getContext());
        final JSObject o = new JSObject();
        o.put("enabled", prefs.isEnabled());
        o.put("sensitivity", prefs.getSensitivity());   // 0 faible, 1 moyenne, 2 élevée
        o.put("wakeSeconds", prefs.getWakeSeconds());
        o.put("maxGapMs", prefs.getMaxGapMs());
        o.put("vibrate", prefs.isVibrate());
        o.put("background", prefs.isBackground());
        o.put("keepCpu", prefs.isKeepCpu());
        return o;
    }

    private JSObject buildStatus() {
        final JSObject o = buildSettings();
        o.put("running", ClapDetectionService.isRunning());
        o.put("micPermission", ClapDetectionService.hasMicPermission(getContext()));
        boolean notif = true;
        if (Build.VERSION.SDK_INT >= 33) {
            notif = ContextCompat.checkSelfPermission(getContext(), Manifest.permission.POST_NOTIFICATIONS)
                    == android.content.pm.PackageManager.PERMISSION_GRANTED;
        }
        o.put("notificationPermission", notif);
        o.put("torchSupported", new TorchController(getContext()).isSupported());
        return o;
    }
}
