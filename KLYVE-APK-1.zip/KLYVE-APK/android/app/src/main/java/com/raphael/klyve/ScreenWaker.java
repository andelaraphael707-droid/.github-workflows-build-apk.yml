package com.raphael.klyve;

import android.content.Context;
import android.os.PowerManager;

/**
 * Réveille l'écran et le maintient allumé un temps limité (5 s par défaut) avec un WakeLock
 * temporaire qui se libère TOUT SEUL (acquire avec délai). Aucun WakeLock n'est jamais oublié.
 *
 * Limites Android : cela allume l'écran (il affiche l'écran de verrouillage) ; cela ne déverrouille pas
 * le téléphone. SCREEN_BRIGHT_WAKE_LOCK est déprécié mais reste le seul moyen pour une appli normale
 * d'allumer l'écran depuis un service, sans contournement de sécurité.
 */
public final class ScreenWaker {

    private final PowerManager powerManager;
    private PowerManager.WakeLock wakeLock;

    public ScreenWaker(Context context) {
        this.powerManager = (PowerManager) context.getApplicationContext().getSystemService(Context.POWER_SERVICE);
    }

    @SuppressWarnings("deprecation")
    public synchronized boolean wakeFor(long millis) {
        if (powerManager == null) {
            return false;
        }
        try {
            release();
            wakeLock = powerManager.newWakeLock(
                    PowerManager.SCREEN_BRIGHT_WAKE_LOCK | PowerManager.ACQUIRE_CAUSES_WAKEUP,
                    "KlyveAI:ClapWake");
            wakeLock.setReferenceCounted(false);
            wakeLock.acquire(millis); // libération automatique après 'millis'
            return true;
        } catch (RuntimeException e) {
            wakeLock = null;
            return false;
        }
    }

    public synchronized void release() {
        try {
            if (wakeLock != null && wakeLock.isHeld()) {
                wakeLock.release();
            }
        } catch (RuntimeException ignored) {
        }
        wakeLock = null;
    }
}
