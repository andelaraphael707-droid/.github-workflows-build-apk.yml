package com.raphael.klyve;

import android.Manifest;
import android.content.ActivityNotFoundException;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.Settings;
import android.widget.Toast;

import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.appcompat.app.AlertDialog;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

import com.getcapacitor.BridgeActivity;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

/**
 * Activité principale Capacitor. index.html (l'interface de KLYVE AI) n'est PAS modifié : tout le
 * natif « claps » vit autour de lui (service, plugin, tuile, raccourcis, boîtes de dialogue système).
 *
 * Cycle de vie :
 *  - onStart  : relance la détection si elle était activée (l'appli est visible → Android l'autorise) ;
 *  - onStop   : coupe la détection si l'option « arrière-plan » est désactivée ;
 *  - onDestroy: ferme les dialogues (pas de fuite de fenêtre). Le service, lui, reste géré par Android
 *               et s'arrête proprement (micro, torche et WakeLocks libérés) dans son onDestroy.
 */
public class MainActivity extends BridgeActivity {

    public static final String ACTION_ENABLE_CLAPS = "com.raphael.klyve.action.ENABLE_CLAPS";
    public static final String ACTION_DISABLE_CLAPS = "com.raphael.klyve.action.DISABLE_CLAPS";

    public interface PermissionCallback {
        void onResult(boolean micGranted);
    }

    private ClapPrefs prefs;
    private PermissionCallback pendingCallback;
    private AlertDialog currentDialog;

    private final ActivityResultLauncher<String[]> permissionLauncher =
            registerForActivityResult(new ActivityResultContracts.RequestMultiplePermissions(),
                    this::onPermissionsResult);

    @Override
    public void onCreate(Bundle savedInstanceState) {
        registerPlugin(KlyveClapPlugin.class); // plugin natif « KlyveClap » (avant super.onCreate)
        super.onCreate(savedInstanceState);
        prefs = new ClapPrefs(this);
        handleIntent(getIntent());
    }

    @Override
    public void onNewIntent(Intent intent) {
        super.onNewIntent(intent);
        setIntent(intent);
        handleIntent(intent);
    }

    @Override
    public void onStart() {
        super.onStart();
        resumeIfEnabled();
        maybeAskFirstLaunch();
    }

    @Override
    public void onStop() {
        super.onStop();
        // Option « détection en arrière-plan » désactivée : on n'écoute que si l'appli est visible
        if (!prefs.isBackground() && ClapDetectionService.isRunning()) {
            ClapDetectionService.stop(this);
        }
    }

    @Override
    public void onDestroy() {
        if (currentDialog != null && currentDialog.isShowing()) {
            currentDialog.dismiss();
        }
        currentDialog = null;
        pendingCallback = null;
        super.onDestroy();
    }

    // ------------------------------------------------------------ intents (raccourcis, tuile)

    private void handleIntent(Intent intent) {
        if (intent == null || intent.getAction() == null) {
            return;
        }
        final String action = intent.getAction();
        if (ACTION_ENABLE_CLAPS.equals(action)) {
            intent.setAction(null);
            prefs.setAsked(true);
            getWindow().getDecorView().post(this::enableClaps);
        } else if (ACTION_DISABLE_CLAPS.equals(action)) {
            intent.setAction(null);
            disableClaps(true);
        }
    }

    // ------------------------------------------------------------ activer / désactiver

    /** Active les claps : demande les autorisations si nécessaire, puis démarre le service. */
    public void enableClaps() {
        if (ClapDetectionService.hasMicPermission(this)) {
            startDetection();
        } else {
            requestClapPermissions(granted -> {
                if (granted) {
                    startDetection();
                } else {
                    toast(R.string.toast_no_mic);
                }
            });
        }
    }

    private void startDetection() {
        prefs.setEnabled(true);
        if (ClapDetectionService.start(this)) {
            toast(R.string.toast_claps_on);
        } else {
            toast(R.string.toast_start_failed);
        }
    }

    public void disableClaps(boolean showToast) {
        prefs.setEnabled(false);
        ClapDetectionService.stop(this);
        if (showToast) {
            toast(R.string.toast_claps_off);
        }
    }

    private void resumeIfEnabled() {
        if (!prefs.isEnabled() || ClapDetectionService.isRunning()) {
            return;
        }
        if (!ClapDetectionService.hasMicPermission(this)) {
            // L'utilisateur a retiré la permission micro dans les réglages Android
            prefs.setEnabled(false);
            toast(R.string.toast_mic_revoked);
            ClapEvents.emit("error", false, false, getString(R.string.toast_mic_revoked));
            return;
        }
        if (!ClapDetectionService.start(this)) {
            toast(R.string.toast_start_failed);
        }
    }

    // ------------------------------------------------------------ permissions

    private boolean has(String permission) {
        return ContextCompat.checkSelfPermission(this, permission) == PackageManager.PERMISSION_GRANTED;
    }

    /** Explique pourquoi, puis demande micro (+ notifications sur Android 13+). Refus gérés proprement. */
    public void requestClapPermissions(PermissionCallback cb) {
        final boolean micOk = has(Manifest.permission.RECORD_AUDIO);
        final boolean notifWanted = Build.VERSION.SDK_INT >= 33
                && !has(Manifest.permission.POST_NOTIFICATIONS) && !prefs.wasNotifAsked();
        if (micOk && !notifWanted) {
            cb.onResult(true);
            return;
        }
        if (isFinishing()) {
            cb.onResult(micOk);
            return;
        }
        if (pendingCallback != null) {
            pendingCallback.onResult(has(Manifest.permission.RECORD_AUDIO));
        }
        pendingCallback = cb;
        currentDialog = new AlertDialog.Builder(this)
                .setTitle(R.string.dlg_perm_title)
                .setMessage(R.string.dlg_perm_msg)
                .setCancelable(false)
                .setPositiveButton(R.string.dlg_continue, (d, w) -> launchPermissionRequest())
                .setNegativeButton(R.string.dlg_cancel,
                        (d, w) -> finishPermission(has(Manifest.permission.RECORD_AUDIO)))
                .show();
    }

    private void launchPermissionRequest() {
        final List<String> wanted = new ArrayList<>();
        if (!has(Manifest.permission.RECORD_AUDIO)) {
            wanted.add(Manifest.permission.RECORD_AUDIO);
        }
        if (Build.VERSION.SDK_INT >= 33 && !has(Manifest.permission.POST_NOTIFICATIONS)
                && !prefs.wasNotifAsked()) {
            wanted.add(Manifest.permission.POST_NOTIFICATIONS);
            prefs.setNotifAsked(true);
        }
        if (wanted.isEmpty()) {
            finishPermission(true);
            return;
        }
        permissionLauncher.launch(wanted.toArray(new String[0]));
    }

    private void onPermissionsResult(Map<String, Boolean> result) {
        final boolean mic = has(Manifest.permission.RECORD_AUDIO);
        if (!mic) {
            if (!ActivityCompat.shouldShowRequestPermissionRationale(this, Manifest.permission.RECORD_AUDIO)) {
                showSettingsDialog(); // refus définitif : seul l'écran de réglages peut le débloquer
            }
        } else if (Build.VERSION.SDK_INT >= 33 && !has(Manifest.permission.POST_NOTIFICATIONS)) {
            toast(R.string.toast_no_notif);
        }
        finishPermission(mic);
    }

    private void finishPermission(boolean micGranted) {
        final PermissionCallback cb = pendingCallback;
        pendingCallback = null;
        if (cb != null) {
            cb.onResult(micGranted);
        }
    }

    private void showSettingsDialog() {
        if (isFinishing()) {
            return;
        }
        currentDialog = new AlertDialog.Builder(this)
                .setTitle(R.string.dlg_denied_title)
                .setMessage(R.string.dlg_denied_msg)
                .setPositiveButton(R.string.dlg_open_settings, (d, w) -> {
                    try {
                        startActivity(new Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS,
                                Uri.fromParts("package", getPackageName(), null)));
                    } catch (ActivityNotFoundException ignored) {
                    }
                })
                .setNegativeButton(R.string.dlg_close, null)
                .show();
    }

    // ------------------------------------------------------------ premier lancement

    private void maybeAskFirstLaunch() {
        if (prefs.wasAsked() || isFinishing()) {
            return;
        }
        if (currentDialog != null && currentDialog.isShowing()) {
            return;
        }
        currentDialog = new AlertDialog.Builder(this)
                .setTitle(R.string.dlg_first_title)
                .setMessage(R.string.dlg_first_msg)
                .setCancelable(false)
                .setPositiveButton(R.string.dlg_enable, (d, w) -> {
                    prefs.setAsked(true);
                    enableClaps();
                })
                .setNegativeButton(R.string.dlg_later, (d, w) -> prefs.setAsked(true))
                .show();
    }

    private void toast(int resId) {
        try {
            Toast.makeText(this, resId, Toast.LENGTH_LONG).show();
        } catch (RuntimeException ignored) {
        }
    }
}
