package com.raphael.klyve;

import android.content.Context;
import android.content.pm.PackageManager;
import android.hardware.camera2.CameraAccessException;
import android.hardware.camera2.CameraCharacteristics;
import android.hardware.camera2.CameraManager;
import android.os.Handler;
import android.os.Looper;

/**
 * Pilote la lampe torche via CameraManager.setTorchMode() :
 *  - aucune permission CAMERA nécessaire, l'application Appareil photo n'est jamais ouverte ;
 *  - vérifie la présence d'un flash ;
 *  - suit l'état réel de la torche (TorchCallback) : si l'utilisateur l'éteint ailleurs, on le sait ;
 *  - toutes les erreurs sont attrapées (jamais de crash).
 */
public final class TorchController {

    private final Context context;
    private final CameraManager cameraManager;
    private final Handler mainHandler = new Handler(Looper.getMainLooper());
    private String cameraId;
    private volatile boolean torchOn = false;
    private boolean callbackRegistered = false;

    private final CameraManager.TorchCallback torchCallback = new CameraManager.TorchCallback() {
        @Override
        public void onTorchModeChanged(String id, boolean enabled) {
            if (id != null && id.equals(cameraId)) {
                torchOn = enabled;
            }
        }
    };

    public TorchController(Context context) {
        this.context = context.getApplicationContext();
        CameraManager cm = null;
        String id = null;
        try {
            if (this.context.getPackageManager().hasSystemFeature(PackageManager.FEATURE_CAMERA_FLASH)) {
                cm = (CameraManager) this.context.getSystemService(Context.CAMERA_SERVICE);
                id = cm == null ? null : findFlashCameraId(cm);
            }
        } catch (RuntimeException e) {
            cm = null;
            id = null;
        }
        this.cameraManager = cm;
        this.cameraId = id;
    }

    private static String findFlashCameraId(CameraManager cm) {
        try {
            String fallback = null;
            for (String id : cm.getCameraIdList()) {
                CameraCharacteristics cc = cm.getCameraCharacteristics(id);
                Boolean flash = cc.get(CameraCharacteristics.FLASH_INFO_AVAILABLE);
                if (flash != null && flash) {
                    Integer facing = cc.get(CameraCharacteristics.LENS_FACING);
                    if (facing != null && facing == CameraCharacteristics.LENS_FACING_BACK) {
                        return id;
                    }
                    if (fallback == null) {
                        fallback = id;
                    }
                }
            }
            return fallback;
        } catch (CameraAccessException | RuntimeException e) {
            return null;
        }
    }

    /** Le téléphone possède-t-il une torche utilisable ? */
    public boolean isSupported() {
        return cameraManager != null && cameraId != null;
    }

    public boolean isOn() {
        return torchOn;
    }

    /** Commence à suivre l'état réel de la torche. */
    public void start() {
        if (!isSupported() || callbackRegistered) {
            return;
        }
        try {
            cameraManager.registerTorchCallback(torchCallback, mainHandler);
            callbackRegistered = true;
        } catch (RuntimeException ignored) {
        }
    }

    /** Allume/éteint la torche. @return true si la commande a été acceptée. */
    public boolean set(boolean on) {
        if (!isSupported()) {
            return false;
        }
        try {
            cameraManager.setTorchMode(cameraId, on);
            torchOn = on;
            return true;
        } catch (CameraAccessException | IllegalArgumentException | SecurityException e) {
            return false;
        } catch (RuntimeException e) {
            return false;
        }
    }

    /** Éteint la torche et arrête le suivi (à appeler quand la détection s'arrête). */
    public void release() {
        if (isSupported()) {
            if (torchOn) {
                try {
                    cameraManager.setTorchMode(cameraId, false);
                } catch (CameraAccessException | RuntimeException ignored) {
                }
            }
            if (callbackRegistered) {
                try {
                    cameraManager.unregisterTorchCallback(torchCallback);
                } catch (RuntimeException ignored) {
                }
                callbackRegistered = false;
            }
        }
        torchOn = false;
    }
}
