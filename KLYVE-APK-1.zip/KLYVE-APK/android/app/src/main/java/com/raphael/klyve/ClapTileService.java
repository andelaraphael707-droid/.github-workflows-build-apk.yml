package com.raphael.klyve;

import android.app.PendingIntent;
import android.content.Intent;
import android.os.Build;
import android.service.quicksettings.Tile;
import android.service.quicksettings.TileService;

/**
 * Tuile « Claps KLYVE » des réglages rapides : active/désactive la détection sans toucher à
 * l'interface de KLYVE AI.
 *  - Désactiver : immédiat (arrête le service).
 *  - Activer : ouvre l'appli (Android exige qu'elle soit visible pour démarrer le micro), qui
 *    demande les autorisations si besoin puis démarre la détection.
 */
public class ClapTileService extends TileService {

    @Override
    public void onStartListening() {
        super.onStartListening();
        refreshTile();
    }

    @Override
    public void onClick() {
        super.onClick();
        if (isLocked()) {
            unlockAndRun(this::toggle);
        } else {
            toggle();
        }
    }

    private void toggle() {
        final ClapPrefs prefs = new ClapPrefs(this);
        if (prefs.isEnabled() || ClapDetectionService.isRunning()) {
            prefs.setEnabled(false);
            ClapDetectionService.stop(this);
            refreshTile();
            return;
        }
        final Intent open = new Intent(this, MainActivity.class)
                .setAction(MainActivity.ACTION_ENABLE_CLAPS)
                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_SINGLE_TOP);
        try {
            if (Build.VERSION.SDK_INT >= 34) {
                final PendingIntent pi = PendingIntent.getActivity(
                        this, 2, open, PendingIntent.FLAG_IMMUTABLE | PendingIntent.FLAG_UPDATE_CURRENT);
                startActivityAndCollapse(pi);
            } else {
                startActivityAndCollapseLegacy(open);
            }
        } catch (RuntimeException ignored) {
        }
    }

    @SuppressWarnings("deprecation")
    private void startActivityAndCollapseLegacy(Intent intent) {
        startActivityAndCollapse(intent);
    }

    private void refreshTile() {
        final Tile tile = getQsTile();
        if (tile == null) {
            return;
        }
        final boolean on = ClapDetectionService.isRunning() || new ClapPrefs(this).isEnabled();
        tile.setState(on ? Tile.STATE_ACTIVE : Tile.STATE_INACTIVE);
        tile.setLabel(getString(R.string.tile_label));
        tile.updateTile();
    }
}
