package com.raphael.klyve;

/**
 * Détecteur de « double clap » 100 % local (aucune dépendance Android, aucun enregistrement).
 *
 * Il reçoit des échantillons PCM 16 bits mono à 16 kHz et les analyse par trames de 20 ms,
 * sans allocation dans la boucle de traitement (économie de batterie / pas de pression GC).
 *
 * Un « clap » valide doit cumuler :
 *  1. un pic d'énergie nettement supérieur au bruit ambiant (seuil ADAPTATIF, rapport configurable) ;
 *  2. une attaque brutale (énergie >= 2x celle de la trame précédente) ;
 *  3. une durée très courte (l'énergie retombe en moins de ~160 ms) → rejette voix, musique, TV,
 *     moteur, bruit continu ;
 *  4. un spectre « brillant » (beaucoup d'énergie aigüe) → rejette les chocs graves (porte, table, basse) ;
 *  5. un niveau ambiant raisonnable (pas de détection dans un environnement déjà très bruyant).
 *
 * Un « double clap » = 2 claps espacés de [150 ms ; maxGap] (par défaut 700 ms), puis un court
 * silence de confirmation (350 ms) : un 3e clap (applaudissements) annule le déclenchement.
 * Après un déclenchement, 1 s de blocage évite les doubles déclenchements.
 *
 * Le temps est mesuré en nombre d'échantillons traités (pas d'horloge système) : le comportement
 * est déterministe et testable hors d'Android.
 */
public final class ClapDetector {

    /** Appelé (sur le thread qui appelle process) quand un double clap est confirmé. */
    public interface Listener {
        void onDoubleClap();
    }

    public static final int SAMPLE_RATE = 16000;
    /** 20 ms à 16 kHz. */
    public static final int FRAME_SIZE = 320;

    // ---- Paramètres de l'algorithme ----
    private static final double DC_R = 0.995;              // filtre anti-offset continu
    private static final double AMBIENT_ALPHA = 0.03;      // vitesse d'adaptation du bruit ambiant
    private static final double AMBIENT_FLOOR = 60.0;      // plancher du bruit ambiant (unités int16)
    private static final double ATTACK_RATIO = 2.0;        // attaque brutale vs trame précédente
    private static final double DECAY_RATIO = 0.35;        // « retombé » = < 35 % du pic
    private static final double DECAY_AMBIENT_MULT = 1.5;  // ... ou < 1,5x l'ambiant
    private static final double MIN_HF_RATIO = 0.30;       // brillance minimale (énergie aigüe)
    private static final int MAX_CLAP_FRAMES = 8;          // 8 x 20 ms = 160 ms max
    private static final long REFRACTORY_MS = 90;          // ignore l'écho juste après un clap
    private static final long MIN_GAP_MS = 150;            // écart minimal entre les 2 claps
    private static final long CONFIRM_QUIET_MS = 350;      // silence de confirmation après le 2e clap
    private static final long COOLDOWN_MS = 1000;          // blocage après déclenchement
    private static final long APPLAUSE_LOCKOUT_MS = 1500;  // blocage si 3e clap (applaudissements)

    private static final int ST_IDLE = 0;
    private static final int ST_CANDIDATE = 1;
    private static final int ST_SUSTAINED = 2;
    private static final int ST_REFRACTORY = 3;

    private static final double[] ONSET_RATIO = {7.0, 5.0, 3.5};      // faible / moyenne / élevée
    private static final double[] MIN_PEAK_RMS = {2200.0, 1500.0, 900.0};
    private static final double[] AMBIENT_LIMIT = {1500.0, 2500.0, 3500.0};

    private final Listener listener;
    private final short[] frame = new short[FRAME_SIZE];
    private int frameFill = 0;

    // Configuration
    private double onsetRatio = ONSET_RATIO[1];
    private double minPeakRms = MIN_PEAK_RMS[1];
    private double ambientLimit = AMBIENT_LIMIT[1];
    private long maxGapMs = 700;

    // État du traitement du signal
    private double dcPrevX = 0;
    private double dcPrevY = 0;
    private double prevRms = 0;
    private double ambient = 150.0;
    private long samplesSeen = 0;
    private int state = ST_IDLE;
    private double candPeak = 0;
    private double candHf = 0;
    private double candAmbient = 0;
    private int candLoudFrames = 0;
    private long candStartMs = 0;
    private long refractoryUntilMs = 0;

    // État du double clap
    private long firstClapMs = -1;
    private boolean pendingConfirm = false;
    private long confirmDeadlineMs = 0;
    private long lockoutUntilMs = 0;

    // Statistiques (utiles aux tests)
    private int clapCount = 0;

    public ClapDetector(Listener listener) {
        this.listener = listener;
    }

    /**
     * @param sensitivity 0 = faible, 1 = moyenne, 2 = élevée
     * @param maxGapMs    délai maximal entre les deux claps (borné à 300..1200 ms)
     */
    public synchronized void configure(int sensitivity, int maxGapMs) {
        int s = Math.max(0, Math.min(2, sensitivity));
        this.onsetRatio = ONSET_RATIO[s];
        this.minPeakRms = MIN_PEAK_RMS[s];
        this.ambientLimit = AMBIENT_LIMIT[s];
        this.maxGapMs = Math.max(300, Math.min(1200, maxGapMs));
    }

    /** Remet l'état interne à zéro (conserve la configuration). */
    public synchronized void reset() {
        frameFill = 0;
        dcPrevX = 0;
        dcPrevY = 0;
        prevRms = 0;
        ambient = 150.0;
        samplesSeen = 0;
        state = ST_IDLE;
        candPeak = 0;
        candHf = 0;
        candAmbient = 0;
        candLoudFrames = 0;
        candStartMs = 0;
        refractoryUntilMs = 0;
        firstClapMs = -1;
        pendingConfirm = false;
        confirmDeadlineMs = 0;
        lockoutUntilMs = 0;
        clapCount = 0;
    }

    public synchronized int getClapCount() {
        return clapCount;
    }

    /** Traite un bloc d'échantillons de longueur quelconque. */
    public synchronized void process(short[] buf, int len) {
        int pos = 0;
        while (pos < len) {
            int n = Math.min(FRAME_SIZE - frameFill, len - pos);
            System.arraycopy(buf, pos, frame, frameFill, n);
            frameFill += n;
            pos += n;
            if (frameFill == FRAME_SIZE) {
                processFrame();
                frameFill = 0;
            }
        }
    }

    // ------------------------------------------------------------------ interne

    private void processFrame() {
        final long tStart = samplesSeen * 1000L / SAMPLE_RATE;
        samplesSeen += FRAME_SIZE;
        final long tEnd = samplesSeen * 1000L / SAMPLE_RATE;

        // Caractéristiques de la trame : énergie (RMS) et « brillance » (RMS de la dérivée / RMS)
        double sumSq = 0;
        double sumDiffSq = 0;
        double yPrev = dcPrevY;
        for (int i = 0; i < FRAME_SIZE; i++) {
            final double x = frame[i];
            final double y = x - dcPrevX + DC_R * dcPrevY;
            dcPrevX = x;
            dcPrevY = y;
            final double d = y - yPrev;
            yPrev = y;
            sumSq += y * y;
            sumDiffSq += d * d;
        }
        final double rms = Math.sqrt(sumSq / FRAME_SIZE);
        final double diffRms = Math.sqrt(sumDiffSq / FRAME_SIZE);
        final double hf = diffRms / (rms + 1.0);

        switch (state) {
            case ST_IDLE:
                if (rms >= minPeakRms
                        && rms >= onsetRatio * Math.max(ambient, AMBIENT_FLOOR)
                        && rms >= ATTACK_RATIO * prevRms
                        && ambient <= ambientLimit) {
                    state = ST_CANDIDATE;
                    candPeak = rms;
                    candHf = hf;
                    candAmbient = Math.max(ambient, AMBIENT_FLOOR);
                    candLoudFrames = 1;
                    candStartMs = tStart;
                }
                break;

            case ST_CANDIDATE:
                if (rms > candPeak) {
                    candPeak = rms;
                    candHf = hf;
                }
                if (rms < Math.max(DECAY_RATIO * candPeak, DECAY_AMBIENT_MULT * candAmbient)) {
                    // L'énergie est retombée vite : son bref. Est-il « brillant » comme un clap ?
                    if (candHf >= MIN_HF_RATIO) {
                        onClap(candStartMs);
                    }
                    state = ST_REFRACTORY;
                    refractoryUntilMs = tEnd + REFRACTORY_MS;
                } else {
                    candLoudFrames++;
                    if (candLoudFrames >= MAX_CLAP_FRAMES) {
                        state = ST_SUSTAINED; // trop long : voix, musique, moteur... → rejeté
                    }
                }
                break;

            case ST_SUSTAINED:
                if (rms < Math.max(0.4 * candPeak, 2.0 * ambient)) {
                    state = ST_REFRACTORY;
                    refractoryUntilMs = tEnd + REFRACTORY_MS;
                }
                break;

            default: // ST_REFRACTORY
                if (tEnd >= refractoryUntilMs) {
                    state = ST_IDLE;
                }
                break;
        }

        // Bruit ambiant adaptatif : monte lentement (les pics sont plafonnés), redescend vite.
        final double clamped = Math.min(rms, 3.0 * ambient + 50.0);
        ambient += (clamped - ambient) * AMBIENT_ALPHA;
        prevRms = rms;

        // Gestion du temps pour le double clap
        if (pendingConfirm && tEnd >= confirmDeadlineMs) {
            if (state == ST_CANDIDATE) {
                // un son est en cours d'analyse : on attend sa résolution
            } else if (state == ST_SUSTAINED) {
                pendingConfirm = false; // bruit continu juste après : on annule
                firstClapMs = -1;
            } else {
                pendingConfirm = false;
                firstClapMs = -1;
                lockoutUntilMs = tEnd + COOLDOWN_MS;
                if (listener != null) {
                    listener.onDoubleClap();
                }
            }
        } else if (!pendingConfirm && firstClapMs >= 0
                && state != ST_CANDIDATE && tEnd - firstClapMs > maxGapMs + 200) {
            firstClapMs = -1; // le premier clap est périmé
        }
    }

    private void onClap(long tMs) {
        clapCount++;
        if (tMs < lockoutUntilMs) {
            return;
        }
        if (pendingConfirm) {
            // 3e clap : applaudissements, pas une commande → on annule tout
            pendingConfirm = false;
            firstClapMs = -1;
            lockoutUntilMs = tMs + APPLAUSE_LOCKOUT_MS;
            return;
        }
        if (firstClapMs < 0) {
            firstClapMs = tMs;
            return;
        }
        final long gap = tMs - firstClapMs;
        if (gap < MIN_GAP_MS) {
            return; // écho / rebond
        }
        if (gap <= maxGapMs) {
            pendingConfirm = true;
            confirmDeadlineMs = tMs + CONFIRM_QUIET_MS;
        } else {
            firstClapMs = tMs; // trop tard : ce clap devient le premier
        }
    }
}
