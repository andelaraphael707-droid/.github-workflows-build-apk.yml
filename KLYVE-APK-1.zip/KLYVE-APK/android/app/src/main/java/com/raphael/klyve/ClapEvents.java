package com.raphael.klyve;

/**
 * Petit bus d'événements statique entre le service natif et le plugin Capacitor.
 * Un seul écouteur (celui du plugin) : pas de fuite, il est retiré quand le plugin est détruit.
 */
public final class ClapEvents {

    public interface Listener {
        /**
         * @param type    "status" (état changé), "doubleClap" (détection) ou "error"
         * @param message texte lisible (peut être null)
         */
        void onEvent(String type, boolean running, boolean torchOn, String message);
    }

    private static volatile Listener listener;

    private ClapEvents() {
    }

    public static void setListener(Listener l) {
        listener = l;
    }

    public static void emit(String type, boolean running, boolean torchOn, String message) {
        Listener l = listener;
        if (l != null) {
            try {
                l.onEvent(type, running, torchOn, message);
            } catch (RuntimeException ignored) {
                // un écouteur défaillant ne doit jamais faire planter le service
            }
        }
    }
}
