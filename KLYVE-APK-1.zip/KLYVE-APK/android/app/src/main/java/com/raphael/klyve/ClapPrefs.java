package com.raphael.klyve;

import android.content.Context;
import android.content.SharedPreferences;

/**
 * Réglages NATIFS de la détection des claps (SharedPreferences privées à l'appli).
 * index.html n'est pas modifié : ces réglages sont modifiables via le plugin Capacitor "KlyveClap"
 * (voir README) pour une future intégration dans l'interface.
 */
public final class ClapPrefs {

    private static final String FILE = "klyve_native_prefs";

    private static final String K_ENABLED = "clap_enabled";
    private static final String K_ASKED = "clap_asked";
    private static final String K_SENSITIVITY = "clap_sensitivity";
    private static final String K_WAKE_SECONDS = "clap_wake_seconds";
    private static final String K_VIBRATE = "clap_vibrate";
    private static final String K_BACKGROUND = "clap_background";
    private static final String K_MAX_GAP = "clap_max_gap_ms";
    private static final String K_KEEP_CPU = "clap_keep_cpu";
    private static final String K_NOTIF_ASKED = "clap_notif_asked";

    private final SharedPreferences sp;

    public ClapPrefs(Context context) {
        this.sp = context.getApplicationContext().getSharedPreferences(FILE, Context.MODE_PRIVATE);
    }

    /** Détection des claps : ON/OFF (par défaut OFF tant que l'utilisateur n'a pas accepté). */
    public boolean isEnabled() {
        return sp.getBoolean(K_ENABLED, false);
    }

    public void setEnabled(boolean v) {
        sp.edit().putBoolean(K_ENABLED, v).apply();
    }

    /** La boîte de dialogue de premier lancement a-t-elle déjà été montrée ? */
    public boolean wasAsked() {
        return sp.getBoolean(K_ASKED, false);
    }

    public void setAsked(boolean v) {
        sp.edit().putBoolean(K_ASKED, v).apply();
    }

    /** Sensibilité : 0 = faible, 1 = moyenne (défaut), 2 = élevée. */
    public int getSensitivity() {
        return clamp(sp.getInt(K_SENSITIVITY, 1), 0, 2);
    }

    public void setSensitivity(int v) {
        sp.edit().putInt(K_SENSITIVITY, clamp(v, 0, 2)).apply();
    }

    /** Durée de maintien de l'écran allumé (secondes, défaut 5, borné 1..30). */
    public int getWakeSeconds() {
        return clamp(sp.getInt(K_WAKE_SECONDS, 5), 1, 30);
    }

    public void setWakeSeconds(int v) {
        sp.edit().putInt(K_WAKE_SECONDS, clamp(v, 1, 30)).apply();
    }

    /** Vibration courte de confirmation (défaut ON). */
    public boolean isVibrate() {
        return sp.getBoolean(K_VIBRATE, true);
    }

    public void setVibrate(boolean v) {
        sp.edit().putBoolean(K_VIBRATE, v).apply();
    }

    /** Détection en arrière-plan (défaut ON). Si OFF : écoute seulement quand l'appli est visible. */
    public boolean isBackground() {
        return sp.getBoolean(K_BACKGROUND, true);
    }

    public void setBackground(boolean v) {
        sp.edit().putBoolean(K_BACKGROUND, v).apply();
    }

    /** Délai maximal entre les 2 claps en ms (défaut 700, borné 300..1200). */
    public int getMaxGapMs() {
        return clamp(sp.getInt(K_MAX_GAP, 700), 300, 1200);
    }

    public void setMaxGapMs(int v) {
        sp.edit().putInt(K_MAX_GAP, clamp(v, 300, 1200)).apply();
    }

    /**
     * Garde le CPU éveillé pendant l'écoute (WakeLock partiel). Défaut OFF pour économiser la batterie ;
     * à activer si la détection « s'endort » écran éteint sur certains téléphones.
     */
    public boolean isKeepCpu() {
        return sp.getBoolean(K_KEEP_CPU, false);
    }

    public void setKeepCpu(boolean v) {
        sp.edit().putBoolean(K_KEEP_CPU, v).apply();
    }

    /** La permission de notification (Android 13+) a-t-elle déjà été demandée ? (on ne harcèle pas) */
    public boolean wasNotifAsked() {
        return sp.getBoolean(K_NOTIF_ASKED, false);
    }

    public void setNotifAsked(boolean v) {
        sp.edit().putBoolean(K_NOTIF_ASKED, v).apply();
    }

    private static int clamp(int v, int min, int max) {
        return Math.max(min, Math.min(max, v));
    }
}
