# Règles ProGuard/R8 (minification désactivée par défaut dans ce projet).
# Conserver les plugins Capacitor si tu actives un jour minifyEnabled :
-keep class com.getcapacitor.** { *; }
-keep class com.raphael.klyve.** { *; }
-keepattributes *Annotation*
