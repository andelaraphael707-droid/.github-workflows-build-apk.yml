import com.raphael.klyve.ClapDetector;

import java.util.Random;

/**
 * Simulation de ClapDetector avec des SIGNAUX SYNTHÉTIQUES (claps modélisés, voix, musique,
 * bruit, chocs graves). Ce n'est PAS un test avec un vrai micro : les seuils devront être
 * confirmés sur le téléphone (voir README, section « Réglage des seuils »).
 *
 * Lancer :  npm run test:claps   (nécessite un JDK : javac + java)
 */
public class ClapDetectorSim {

    static final int FS = ClapDetector.SAMPLE_RATE;

    static int passed = 0;
    static int failed = 0;

    // ---------------------------------------------------------------- générateurs
    static double[] silence(double seconds) {
        return new double[(int) (seconds * FS)];
    }

    static void addNoise(double[] s, double rms, Random r) {
        for (int i = 0; i < s.length; i++) s[i] += r.nextGaussian() * rms;
    }

    /** Clap modélisé : bruit large bande (passe-haut) avec enveloppe très courte + petite queue de réverbération. */
    static void addClap(double[] s, double atSec, double amp, Random r) {
        int start = (int) (atSec * FS);
        double prev = 0;
        for (int n = 0; n < (int) (0.25 * FS) && start + n < s.length; n++) {
            double t = n / (double) FS;
            double env = Math.exp(-t / 0.006) + 0.12 * Math.exp(-t / 0.05);
            double g = r.nextGaussian();
            double hp = g - 0.7 * prev;
            prev = g;
            s[start + n] += amp * env * hp;
        }
    }

    /** Choc grave (porte, table) : sinusoïde amortie à ~110 Hz. */
    static void addThump(double[] s, double atSec, double amp) {
        int start = (int) (atSec * FS);
        for (int n = 0; n < (int) (0.3 * FS) && start + n < s.length; n++) {
            double t = n / (double) FS;
            s[start + n] += amp * Math.exp(-t / 0.03) * Math.sin(2 * Math.PI * 110 * t);
        }
    }

    /** Voix : harmoniques de 120 Hz avec pente spectrale, syllabes à ~4 Hz, souffle léger. */
    static void addSpeech(double[] s, double fromSec, double toSec, double level, Random r) {
        int a = (int) (fromSec * FS), b = Math.min(s.length, (int) (toSec * FS));
        double phase0 = r.nextDouble() * 6.28;
        for (int i = a; i < b; i++) {
            double t = i / (double) FS;
            double f0 = 120 + 25 * Math.sin(2 * Math.PI * 0.7 * t + phase0);
            double syl = Math.pow(Math.abs(Math.sin(2 * Math.PI * 4.0 * t + phase0)), 1.5);
            double v = 0;
            for (int k = 1; k <= 25; k++) {
                v += Math.sin(2 * Math.PI * f0 * k * t) / k;
            }
            s[i] += level * 0.9 * syl * v + level * 0.08 * syl * r.nextGaussian();
        }
    }

    /** Musique : basse + accord + kick grave (2 Hz) + charleston (4 Hz, court et aigu). */
    static void addMusic(double[] s, double fromSec, double toSec, double level, Random r) {
        int a = (int) (fromSec * FS), b = Math.min(s.length, (int) (toSec * FS));
        double prevG = 0;
        for (int i = a; i < b; i++) {
            double t = i / (double) FS;
            double v = 0.5 * Math.sin(2 * Math.PI * 65 * t) + 0.3 * Math.sin(2 * Math.PI * 261 * t)
                    + 0.25 * Math.sin(2 * Math.PI * 329 * t) + 0.2 * Math.sin(2 * Math.PI * 392 * t);
            double kickPos = (t * 2.0) % 1.0; // un kick toutes les 0,5 s
            v += 1.8 * Math.exp(-kickPos / 0.06) * Math.sin(2 * Math.PI * 55 * kickPos);
            double hatPos = (t * 4.0) % 1.0; // charleston toutes les 0,25 s
            double g = r.nextGaussian();
            v += 0.9 * Math.exp(-hatPos / 0.03) * (g - 0.7 * prevG);
            prevG = g;
            s[i] += level * v;
        }
    }

    // ---------------------------------------------------------------- exécution
    static int run(double[] sig, int sensitivity, int maxGap) {
        final int[] fires = {0};
        ClapDetector d = new ClapDetector(() -> fires[0]++);
        d.configure(sensitivity, maxGap);
        short[] buf = new short[ClapDetector.FRAME_SIZE * 3 + 7]; // taille volontairement « bancale »
        int pos = 0;
        while (pos < sig.length) {
            int n = Math.min(buf.length, sig.length - pos);
            for (int i = 0; i < n; i++) {
                double v = Math.max(-32768, Math.min(32767, sig[pos + i]));
                buf[i] = (short) Math.round(v);
            }
            d.process(buf, n);
            pos += n;
        }
        return fires[0];
    }

    static void check(String name, int got, int expected) {
        boolean ok = got == expected;
        if (ok) passed++; else failed++;
        System.out.printf("%s  %-62s déclenchements=%d (attendu %d)%n", ok ? "OK  " : "ECHEC", name, got, expected);
    }

    static double[] scene(double seconds, double noise, long seed) {
        double[] s = silence(seconds);
        addNoise(s, noise, new Random(seed));
        return s;
    }

    public static void main(String[] args) {
        Random r = new Random(42);

        System.out.println("=== Scénarios ciblés (sensibilité moyenne, écart max 700 ms) ===");
        double[] s;

        s = scene(5, 150, 1); addClap(s, 1.0, 9000, r); addClap(s, 1.4, 9000, r);
        check("2 claps (écart 400 ms) dans une pièce calme", run(s, 1, 700), 1);

        s = scene(5, 150, 2); addClap(s, 1.0, 9000, r);
        check("1 seul clap", run(s, 1, 700), 0);

        s = scene(6, 150, 3); addClap(s, 1.0, 9000, r); addClap(s, 1.3, 9000, r); addClap(s, 1.6, 9000, r);
        check("3 claps rapprochés (applaudissements)", run(s, 1, 700), 0);

        s = scene(7, 150, 4); for (int i = 0; i < 6; i++) addClap(s, 1.0 + 0.3 * i, 9000, r);
        check("6 claps rapprochés (applaudissements)", run(s, 1, 700), 0);

        s = scene(6, 150, 5); addClap(s, 1.0, 9000, r); addClap(s, 2.3, 9000, r);
        check("2 claps trop espacés (1,3 s)", run(s, 1, 700), 0);

        s = scene(5, 150, 6); addClap(s, 1.0, 9000, r); addClap(s, 1.09, 9000, r);
        check("2 claps collés (90 ms) = écho, pas un double clap", run(s, 1, 700), 0);

        s = scene(5, 150, 7); addClap(s, 1.0, 9000, r); addClap(s, 1.2, 9000, r);
        check("2 claps rapides (écart 200 ms)", run(s, 1, 700), 1);

        s = scene(5, 150, 8); addClap(s, 1.0, 9000, r); addClap(s, 1.65, 9000, r);
        check("2 claps lents (écart 650 ms)", run(s, 1, 700), 1);

        s = scene(9, 150, 9); addClap(s, 1.0, 9000, r); addClap(s, 1.4, 9000, r); addClap(s, 4.0, 9000, r); addClap(s, 4.4, 9000, r);
        check("2 doubles claps à 3 s d'écart (allumer puis éteindre)", run(s, 1, 700), 2);

        s = scene(5, 450, 10); addClap(s, 1.0, 9000, r); addClap(s, 1.4, 9000, r);
        check("2 claps avec ventilateur/bruit de fond (450 RMS)", run(s, 1, 700), 1);

        s = scene(5, 150, 11); addClap(s, 1.0, 2500, r); addClap(s, 1.4, 2500, r);
        check("2 claps très faibles, sensibilité MOYENNE (attendu : ignorés)", run(s, 1, 700), 0);
        check("2 claps très faibles, sensibilité ÉLEVÉE", run(s, 2, 700), 1);

        s = scene(5, 150, 12); addClap(s, 1.0, 9000, r); addClap(s, 1.4, 9000, r);
        check("Sensibilité FAIBLE, claps forts", run(s, 0, 700), 1);

        System.out.println();
        System.out.println("=== Faux positifs (doivent rester à 0) ===");

        s = scene(20, 120, 20); addSpeech(s, 2, 18, 2500, r);
        check("Voix continue (16 s)", run(s, 1, 700), 0);
        check("Voix continue, sensibilité ÉLEVÉE", run(s, 2, 700), 0);

        s = scene(30, 120, 21); addMusic(s, 2, 28, 1800, r);
        check("Musique avec kick + charleston (26 s)", run(s, 1, 700), 0);
        check("Musique, sensibilité ÉLEVÉE", run(s, 2, 700), 0);

        s = scene(12, 100, 22); addNoise(s, 0, r);
        double[] wn = scene(12, 100, 23);
        for (int i = (int) (2 * FS); i < wn.length; i++) wn[i] += new Random(i).nextGaussian() * 2000;
        check("Bruit blanc continu fort (TV, souffle, moteur)", run(wn, 1, 700), 0);

        s = scene(6, 120, 24); addThump(s, 1.0, 12000); addThump(s, 1.4, 12000);
        check("2 coups GRAVES (porte / table)", run(s, 1, 700), 0);

        s = scene(6, 120, 25);
        for (int i = 0; i < s.length; i++) s[i] += 9000 * Math.sin(2 * Math.PI * 1000 * i / (double) FS) * (i > FS && i < 1.3 * FS ? 1 : 0);
        for (int i = 0; i < s.length; i++) s[i] += 9000 * Math.sin(2 * Math.PI * 1000 * i / (double) FS) * (i > 1.5 * FS && i < 1.8 * FS ? 1 : 0);
        check("2 bips de notification (1 kHz, 300 ms)", run(s, 1, 700), 0);

        s = scene(6, 100, 26);
        for (int i = 0; i < s.length; i++) s[i] += 500 * Math.sin(2 * Math.PI * 300 * i / (double) FS);
        check("Bourdonnement continu faible", run(s, 1, 700), 0);

        System.out.println();
        System.out.println("=== Statistique : 200 essais aléatoires (claps 5000–12000, bruit 80–600, écart 200–650 ms) ===");
        int hit = 0, trials = 200;
        for (int k = 0; k < trials; k++) {
            Random rr = new Random(1000 + k);
            double noise = 80 + rr.nextDouble() * 520;
            double a1 = 5000 + rr.nextDouble() * 7000, a2 = 5000 + rr.nextDouble() * 7000;
            double gap = 0.2 + rr.nextDouble() * 0.45;
            double[] sg = scene(5, noise, 5000 + k);
            addClap(sg, 1.0, a1, rr);
            addClap(sg, 1.0 + gap, a2, rr);
            if (run(sg, 1, 700) == 1) hit++;
        }
        System.out.printf("Détection (sensibilité moyenne) : %d / %d = %.1f %%%n", hit, trials, 100.0 * hit / trials);

        System.out.println();
        System.out.printf("Résultat : %d réussis, %d échoués%n", passed, failed);
        System.exit(failed == 0 ? 0 : 1);
    }
}
