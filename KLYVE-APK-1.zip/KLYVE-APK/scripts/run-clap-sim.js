#!/usr/bin/env node
/* Compile et lance la simulation de l'algorithme de claps (nécessite un JDK : javac + java). */
const { spawnSync } = require('child_process');
const fs = require('fs');
const os = require('os');
const path = require('path');

const root = path.resolve(__dirname, '..');
const out = fs.mkdtempSync(path.join(os.tmpdir(), 'klyve-sim-'));
const srcs = [
  path.join(root, 'android/app/src/main/java/com/raphael/klyve/ClapDetector.java'),
  path.join(root, 'tools/ClapDetectorSim.java'),
];

let r = spawnSync('javac', ['-encoding', 'UTF-8', '-d', out, ...srcs], { stdio: 'inherit' });
if (r.error) {
  // Repli : JDK sans binaire javac dans le PATH
  r = spawnSync('java', ['-m', 'jdk.compiler/com.sun.tools.javac.Main', '-encoding', 'UTF-8', '-d', out, ...srcs], { stdio: 'inherit' });
}
if (r.status !== 0) {
  console.error('Compilation impossible : installe un JDK 21 (voir README).');
  process.exit(1);
}
r = spawnSync('java', ['-Dfile.encoding=UTF-8', '-Dstdout.encoding=UTF-8', '-cp', out, 'ClapDetectorSim'], { stdio: 'inherit' });
process.exit(r.status === null ? 1 : r.status);
