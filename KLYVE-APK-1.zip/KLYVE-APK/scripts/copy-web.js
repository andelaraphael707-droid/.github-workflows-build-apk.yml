#!/usr/bin/env node
/*
 * Copie index.html (inchangé) vers www/ pour Capacitor (webDir = "www").
 * Vérifie que la copie est strictement identique à l'original (SHA-256).
 */
const fs = require('fs');
const path = require('path');
const crypto = require('crypto');

const root = path.resolve(__dirname, '..');
const src = path.join(root, 'index.html');
const destDir = path.join(root, 'www');
const dest = path.join(destDir, 'index.html');

const sha = (f) => crypto.createHash('sha256').update(fs.readFileSync(f)).digest('hex');

if (!fs.existsSync(src)) {
  console.error('[KLYVE] index.html introuvable à la racine du projet.');
  process.exit(1);
}
fs.mkdirSync(destDir, { recursive: true });
fs.copyFileSync(src, dest);

if (sha(src) !== sha(dest)) {
  console.error("[KLYVE] ERREUR : la copie de index.html diffère de l'original.");
  process.exit(1);
}
console.log('[KLYVE] index.html copié dans www/ (identique, SHA-256 ' + sha(dest).slice(0, 12) + '…)');
