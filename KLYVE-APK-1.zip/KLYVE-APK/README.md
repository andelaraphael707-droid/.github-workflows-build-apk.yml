# KLYVE AI — Application Android (Capacitor)

**KLYVE AI** — créée par **KLYVE RAPHAËL**
Package : `com.raphael.klyve` · Capacitor 8 · minSdk 24 (Android 7.0) · targetSdk 36

Ce projet emballe ton `index.html` **sans le modifier** dans une vraie application Android
(WebView Capacitor) et lui ajoute, **autour** de lui, la détection des **2 claps 👏👏**
(torche + réveil de l'écran) en code Android natif.

---

## 0. Ce qui est garanti inchangé

| Élément | État |
|---|---|
| `index.html` (HTML, CSS, JS, texte, interface) | **Identique à l'octet près** à ton fichier. `npm run build` vérifie la copie par SHA-256. |
| Clé API | Ton fichier ne contient **aucune clé** : le champ est vide par défaut (`key:''`) et tu la saisis dans *Paramètres → IA*. L'APK n'embarque donc aucune clé. |
| Prompt système | Inchangé (il est dans `index.html`, non touché). |
| localStorage, historique, mémoire, réglages | Inchangés : stockés dans le WebView de l'application. |
| Interface, couleurs, boutons | Inchangés. Aucun bouton « claps » n'est ajouté dans l'interface (voir §10 pour les contrôles natifs). |

> ⚠️ **Sécurité de la clé API.** Une clé saisie dans une application côté client reste lisible par
> quiconque a accès au téléphone (stockage du WebView, et si tu coches « enregistrer la clé »).
> Pour un usage familial c'est acceptable ; pour une diffusion publique, il faudra passer par un
> petit serveur intermédiaire qui garde la clé. Ce projet ne change rien à ton fonctionnement actuel.

> ⚠️ **Données existantes.** Si tu utilisais KLYVE AI sur Netlify, ta mémoire/ton historique restent
> dans le navigateur : l'APK a son propre stockage (origine différente). Ils ne sont pas copiés
> automatiquement dans l'APK.

---

## 1. Installer Node.js

Capacitor 8 exige **Node.js 22 ou plus**.
Télécharge la version LTS sur <https://nodejs.org>, puis vérifie :

```bash
node -v    # doit afficher v22.x ou plus
npm -v
```

Il te faut aussi **JDK 21** (inclus dans Android Studio Otter) et **Android Studio Otter 2025.2.1 ou plus récent**
(<https://developer.android.com/studio>). Au premier lancement, laisse-le installer le SDK Android 36.

## 2. Installer les dépendances

Dans le dossier du projet :

```bash
npm install
```

Plugins Capacitor installés (versions 8.x, compatibles Capacitor 8) :
`@capacitor/core`, `@capacitor/android`, `@capacitor/cli`, `@capacitor/device`,
`@capacitor/local-notifications`, `@capacitor-community/keep-awake`.

**`@capacitor-community/background-mode` n'est volontairement PAS utilisé.** Je n'ai pas pu confirmer
qu'il existe une version maintenue compatible Capacitor 8 (les forks que j'ai trouvés s'arrêtent à
Capacitor 7). Conformément à ta consigne (« pas de dépendance fictive »), le fonctionnement en
arrière-plan est assuré par un **Foreground Service Android natif** écrit dans ce projet
(`ClapDetectionService.java`), solution officielle d'Android pour écouter le micro en arrière-plan.

## 3. Synchroniser Capacitor

```bash
npm run sync        # = copie index.html → www/ puis "npx cap sync android"
npm run doctor      # = npx cap doctor (diagnostic)
```

`cap sync` génère `android/app/src/main/assets/public/`, `capacitor.config.json` côté Android et
`capacitor.plugins.json`. Les fichiers `capacitor.settings.gradle` / `capacitor.build.gradle` fournis
sont ceux que `cap sync` régénère à l'identique.

## 4. Ouvrir dans Android Studio

```bash
npm run open        # = npx cap open android
```

ou : *Android Studio → Open → dossier `android/`*. Laisse la synchronisation Gradle se terminer.

> **Gradle wrapper.** Le fichier `gradle/wrapper/gradle-wrapper.properties` (Gradle 8.14.3) est fourni,
> mais pas `gradle-wrapper.jar` / `gradlew` (binaires impossibles à générer sans Internet).
> Android Studio gère cela tout seul. En ligne de commande, génère-les une fois :
> ```bash
> cd android
> gradle wrapper --gradle-version 8.14.3     # nécessite Gradle installé (ou ouvrir une fois le projet dans Android Studio)
> ```

## 5. Compiler l'APK

*Android Studio → Build → Build Bundle(s) / APK(s) → Build APK(s).*
Ou en ligne de commande depuis `android/` (voir §6 et §7).

## 6. APK debug (le plus simple, pour tester)

```bash
cd android
./gradlew assembleDebug          # Windows : gradlew.bat assembleDebug
```

Fichier produit : `android/app/build/outputs/apk/debug/app-debug.apk` (signé automatiquement avec la clé debug).

## 7. APK release (signé)

1. Crée ta clé de signature (une seule fois, **sauvegarde-la précieusement**) :
   ```bash
   keytool -genkeypair -v -keystore klyve-release.jks -alias klyve -keyalg RSA -keysize 2048 -validity 10000
   ```
2. Copie `keystore.properties.example` en `keystore.properties` (racine du projet) et remplis les 4 valeurs.
   `build.gradle` signe alors automatiquement la release. **Ne partage jamais ce fichier ni le .jks.**
3. ```bash
   cd android
   ./gradlew assembleRelease
   ```
   Fichier : `android/app/build/outputs/apk/release/app-release.apk`.
   (Sans `keystore.properties`, l'APK release est produite non signée et n'est pas installable.)

## 8. Installer l'APK sur Android

- Copie l'APK sur le téléphone (câble, Drive, Bluetooth…), ouvre-la dans le gestionnaire de fichiers.
- Autorise « Installer des applications inconnues » pour l'application utilisée si Android le demande.
- Ou par USB (débogage activé) : `adb install -r app-debug.apk`.

### Volt.build (VoltBuilder)
Le projet contient déjà `voltbuilder.json` (fichier **obligatoire** chez VoltBuilder) réglé sur une **APK debug** :
pas besoin de keystore, l'APK est signée automatiquement et s'installe directement.

1. Zippe le dossier (le ZIP fourni convient tel quel) et envoie-le sur <https://volt.build/upload/> (case **Android**).
2. Attends 1 à 2 minutes, puis télécharge l'APK (ou ouvre le lien d'installation sur le téléphone).
3. En cas d'échec, clique sur **View Log** et envoie-moi le message d'erreur.

Pour une APK **release** : mets `"release": "release"` dans `voltbuilder.json`, ajoute un dossier `certificates/` avec ton keystore
et les champs `androidKeystore`, `androidKeystorePassword`, `androidAlias`, `androidAliasPassword`
(voir <https://volt.build/docs/set_up-capacitor/>). Ne partage jamais ce keystore.

> Point à surveiller : ce projet utilise **Capacitor 8** (Node 22, Java 21). La documentation VoltBuilder que j'ai lue
> mentionne encore Node 16 et Capacitor 7 ; je n'ai pas pu confirmer le support de Capacitor 8 par leur serveur.
> Si le log parle de version de Node, de Java ou de dépendances, il faudra adapter le projet.

---

## 9. Permissions Android utilisées

| Permission | Pourquoi | Quand elle est demandée |
|---|---|---|
| `INTERNET`, `ACCESS_NETWORK_STATE` | Dialogue avec l'API (HTTPS uniquement) | Installation (automatique) |
| `RECORD_AUDIO` | Entendre les 2 claquements (analyse locale). Sert aussi au test micro de `index.html` | À l'activation des claps, après explication |
| `FOREGROUND_SERVICE`, `FOREGROUND_SERVICE_MICROPHONE` | Service d'écoute au premier plan (obligatoire Android 14+) | Installation (automatique) |
| `POST_NOTIFICATIONS` | Notification « Détection des claps active » avec bouton Arrêter (Android 13+) | À l'activation, après explication (une seule fois) |
| `WAKE_LOCK` | Réveiller l'écran ~5 s | Installation (automatique) |
| `VIBRATE` | Vibration courte de confirmation | Installation (automatique) |
| `CAMERA` | Uniquement pour le test caméra / sécurité faciale **déjà présents** dans `index.html` (`getUserMedia`) | Quand `index.html` la demande |

- **La torche n'utilise pas la permission CAMERA** : elle passe par `CameraManager.setTorchMode()`.
- Le flash, la caméra et le micro sont déclarés `required="false"` : l'appli s'installe même sans.
- Réseau : `network_security_config.xml` interdit tout trafic HTTP en clair. J'ai cherché : `index.html`
  n'utilise **aucune URL `http://`** (seulement `https://api.groq.com`).
- Aucune donnée personnelle collectée, aucun audio enregistré ni envoyé.

## 10. Comment fonctionne la détection « 2 claps »

**Activer / désactiver** (l'interface de `index.html` n'est pas modifiée, donc les contrôles sont natifs) :
- Au **premier lancement**, une boîte de dialogue Android explique la fonction et propose « Activer / Plus tard ».
- **Appui long sur l'icône** de l'application → « Activer les claps » / « Couper les claps ».
- **Tuile « Claps KLYVE »** à ajouter dans les réglages rapides (crayon d'édition).
- Bouton **« Arrêter »** de la notification.

**Cycle de fonctionnement :**
1. 👏👏 → **torche ON**, **écran réveillé**, maintenu ~5 s par un WakeLock temporaire qui se libère tout seul. Vibration courte.
2. 👏👏 suivants → **torche OFF**, WakeLock libéré.
(La torche reste allumée tant que tu ne refais pas 👏👏 ou n'arrêtes pas la détection ; seul l'écran s'éteint après 5 s.)

**Algorithme** (`ClapDetector.java`, local, sans allocation dans la boucle) — un clap doit cumuler :
pic d'énergie ≥ 3,5 à 7× le bruit ambiant **adaptatif** (selon la sensibilité) · attaque brutale (≥ 2× la trame précédente) ·
durée ≤ 160 ms · spectre « brillant » (rejette chocs graves) · ambiant pas trop fort. Un **double clap** =
2 claps espacés de 150 ms à 700 ms (configurable), suivis de 350 ms de calme : un 3ᵉ clap (applaudissements) annule.
Refus des voix, musique, TV, bruit continu, bips de notification, sons faibles.

**Réglages natifs préparés** (sans toucher à `index.html`) via le plugin Capacitor `KlyveClap`, utilisable plus tard :
```js
const { KlyveClap } = Capacitor.Plugins;
await KlyveClap.start();  await KlyveClap.stop();
await KlyveClap.getStatus();
await KlyveClap.setSettings({ sensitivity: 2,   // 0 faible · 1 moyenne · 2 élevée
                              wakeSeconds: 5, vibrate: true, background: true,
                              maxGapMs: 700, keepCpu: false });
KlyveClap.addListener('clapEvent', e => console.log(e)); // {type:'status'|'doubleClap'|'error', running, torchOn, message?}
```

**Réglage des seuils.** Les seuils ont été calibrés sur des signaux **simulés** (voir `npm run test:claps`),
pas sur un vrai micro. Si ça ne se déclenche pas assez : `sensitivity: 2`. Si ça se déclenche trop : `sensitivity: 0`.
Les constantes sont en tête de `ClapDetector.java`.

## 11. Limites Android (à connaître honnêtement)

- **Arrière-plan** : l'écoute continue grâce au Foreground Service et sa notification (obligatoire, visible).
  Android 12+ / 14+ interdit de **démarrer** un service micro depuis l'arrière-plan : la détection démarre donc
  quand l'application est ouverte, puis continue quand tu la quittes. Si Android tue le processus (mémoire
  faible, « arrêt forcé », économiseur de batterie agressif), la détection s'arrête jusqu'à la prochaine ouverture.
  Sur certains téléphones (itel, Xiaomi, Tecno, Huawei…), il faut **désactiver l'optimisation batterie** pour KLYVE AI
  *(Réglages → Applis → KLYVE AI → Batterie → Sans restriction)*.
- **Écran verrouillé / éteint** : l'écran peut s'allumer ~5 s (WakeLock). Le téléphone **n'est pas déverrouillé**
  (interdit par la sécurité Android). Le micro peut être bridé par certains fabricants écran éteint ; l'option
  `keepCpu: true` (WakeLock partiel) peut aider au prix de la batterie.
- **Micro occupé** : pendant un appel ou si une autre appli utilise le micro (reconnaissance vocale, appel vidéo),
  Android peut couper l'écoute ; le service retente 3 fois puis s'arrête proprement avec un message.
- **Torche** : si l'appareil n'a pas de flash, un message clair s'affiche et seul le réveil de l'écran est effectué.
  Si une autre appli utilise le flash/la caméra, la torche peut être refusée (message affiché).
- **Versions d'Android** : `minSdk 24` (Android 7.0). Les téléphones sous Android 6 ou moins ne sont pas supportés par Capacitor 8.
- **WebView** : ton `index.html` tourne dans le WebView d'Android, pas dans Chrome. Certaines API web peuvent
  différer : en particulier **la reconnaissance vocale** (`SpeechRecognition`) et les **notifications web**
  (`Notification`) ne sont en général pas disponibles dans un WebView — `index.html` affichera alors ses messages
  habituels « indisponible ». Les plugins natifs `@capacitor/local-notifications` et `@capacitor/device` sont installés
  pour une intégration future ; ils ne sont **pas** reliés à `index.html` puisqu'il ne doit pas être modifié.

---

## État des tests (honnête)

Cet environnement n'a **ni Internet, ni Android SDK, ni appareil** : `npm install`, `npx cap sync`, `npx cap doctor`,
la compilation Gradle et les tests sur téléphone **n'ont pas pu être exécutés ici**.

| # | Test demandé | État |
|---|---|---|
| 1 | Lancement normal | ⏳ À vérifier sur appareil |
| 2 | KLYVE AI répond à un message | ⏳ Code web strictement inchangé (SHA-256 identique) ; nécessite ta clé Groq |
| 3 | Mémoire / historique | ⏳ localStorage inchangé ; à vérifier sur appareil |
| 4 | Rotation portrait/paysage | ⏳ Configurée (`fullUser`, `configChanges`) ; à vérifier |
| 5 | Permission micro | ⏳ Implémentée (explication → demande → gestion du refus) ; à vérifier |
| 6 | Détection 👏👏 | ✅ Algorithme simulé : 21/21 scénarios, 98,5 % sur 200 essais aléatoires (signaux synthétiques) · ⏳ vrai micro à vérifier |
| 7 | Torche ON | ⏳ Implémentée (`setTorchMode`) ; à vérifier |
| 8 | Écran réveillé ~5 s | ⏳ Implémenté (WakeLock temporaire) ; à vérifier |
| 9 | 2ᵉ 👏👏 → torche OFF | ✅ Logique simulée (2 doubles claps) · ⏳ torche réelle à vérifier |
| 10 | Application minimisée | ⏳ Foreground Service implémenté ; à vérifier |
| 11 | Écran éteint | ⏳ Dans la limite d'Android (§11) ; à vérifier |
| 12 | Permission refusée | ⏳ Implémentée (message + écran de réglages si refus définitif) |
| 13 | Téléphone sans flash | ⏳ Implémenté (message, pas de crash) |
| 14 | Redémarrage de l'appli | ⏳ Reprise automatique si activé (`onStart`) |
| 15 | Aucune erreur de compilation | ⚠️ **Non vérifié** (pas de SDK). Vérifiés ici : XML bien formés, ressources/références cohérentes, aucune permission en double, aucune erreur de syntaxe Java |

Vérifier soi-même : `npm run test:claps` (simulation de l'algorithme, nécessite un JDK).

## Structure

```
KLYVE-APK/
├── index.html                  ← TON fichier, inchangé
├── www/index.html              ← copie identique (webDir Capacitor)
├── package.json · capacitor.config.json · voltbuilder.json · README.md
├── keystore.properties.example
├── scripts/                    copy-web.js · run-clap-sim.js
├── tools/ClapDetectorSim.java  simulation de l'algorithme
├── assets/icon-512.png         icône source
└── android/                    projet Android Studio / Capacitor
    └── app/src/main/
        ├── AndroidManifest.xml
        ├── java/com/raphael/klyve/
        │   ├── MainActivity.java          (cycle de vie, permissions, dialogues)
        │   ├── ClapDetectionService.java  (Foreground Service micro)
        │   ├── ClapDetector.java          (algorithme)
        │   ├── TorchController.java · ScreenWaker.java
        │   ├── ClapPrefs.java · ClapEvents.java
        │   ├── KlyveClapPlugin.java       (pont Capacitor optionnel)
        │   └── ClapTileService.java       (tuile réglages rapides)
        └── res/ …
```

## Évolution future

L'interface web reste la source principale. L'architecture native (service, détecteur, préférences, plugin)
est indépendante du WebView : elle peut être réutilisée telle quelle avec Kotlin / Jetpack Compose,
une Trusted Web Activity ou une WebView native.

© 2026 KLYVE AI — Créé par KLYVE RAPHAËL
